# Claude Code 自举内核实现提示词

你将实现一个“自进化个人 Agent”的第一版自举内核。请注意：本次任务不是实现完整 Jarvis，不要实现手机端、语音识别、咖啡点单、地图、新闻推送等具体高级业务功能。你的目标是实现一个最小但可扩展的 Agent 框架，使它未来能够通过“交互即开发”的方式持续迭代自己。

请严格按以下要求实现。

## 一、项目目标

我要开发的是一个自进化个人管家型 Agent。

第一版目标：

1. Agent 能读取 `docs/` 下的项目文档。
2. Agent 能读取和修改 `mind/` 下的人格、用户模型、交互规则、自我模型。
3. Agent 能读写 `memory/` 下的偏好、反馈、事件和总结。
4. Agent 能维护 `capabilities/registry.md`。
5. Agent 能维护 `self_development/issues.md`、`ideas.md`、`changelog.md`。
6. Agent 能根据用户输入判断应该：
   - 普通回复；
   - 写入偏好；
   - 修改人格；
   - 修改 listen policy；
   - 写入记忆；
   - 创建新能力请求；
   - 创建运行机制修改请求；
   - 记录 bug 反馈；
   - 创建自我开发任务。
7. Agent 能创建 candidate 版本，在 candidate 上修改，通过 health check 后 promote，失败则保留 current。
8. 第一版只实现自举内核，不要实现完整业务功能。

核心产品理念：

> 先写一个会长大的 Agent，而不是先写一个功能很多但不会成长的软件。

## 二、技术要求

请优先使用 Python 实现。若你认为需要其他语言或工具，可以在开始前说明理由，但默认使用 Python。

请实现一个可在本地运行的 CLI 版本即可，不需要 Web UI。

CLI 交互示例：

```text
$ python main.py

User: 我不爱喝瑞幸，我爱喝星巴克。
Agent: 已记录到咖啡偏好中。以后主动推荐咖啡时会优先考虑星巴克，瑞幸工具不会被删除，但会降低主动推荐优先级。

User: 以后我叫你大李的时候你才应，和别人聊天时别插嘴。
Agent: 已更新 listen_policy.md：显式呼叫名增加“大李”，多人对话场景默认 skip。

User: 你给记忆加一个 hit 机制。
Agent: 这是运行机制修改请求。我已创建 self_development issue，并标记涉及 memory_router 和 memory index。当前版本暂未自动修改核心代码。
```

## 三、目录结构

请创建以下目录结构。如果部分文件为空，也要初始化为可读的 Markdown 文件。

```text
jarvis/
├── main.py
├── README.md
├── docs/
│   ├── product_vision_and_v1_architecture.md
│   ├── constitution.md
│   ├── interaction_development_protocol.md
│   ├── memory_design.md
│   ├── capability_design.md
│   └── self_improvement_protocol.md
│
├── core/
│   ├── __init__.py
│   ├── agent_loop.py
│   ├── context_builder.py
│   ├── intent_classifier.py
│   ├── memory_router.py
│   ├── capability_router.py
│   ├── tool_router.py
│   ├── self_model_manager.py
│   └── file_store.py
│
├── mind/
│   ├── system_prompt.md
│   ├── persona.md
│   ├── user_model.md
│   ├── listen_policy.md
│   ├── goals.md
│   ├── daily_context.md
│   └── self_model.md
│
├── memory/
│   ├── preferences/
│   │   └── README.md
│   ├── feedback/
│   │   └── README.md
│   ├── events/
│   │   └── README.md
│   ├── summaries/
│   │   └── README.md
│   ├── archive/
│   │   └── README.md
│   └── index/
│       └── README.md
│
├── capabilities/
│   ├── registry.md
│   ├── local_tools/
│   │   └── README.md
│   ├── workflows/
│   │   └── README.md
│   ├── mcp/
│   │   └── README.md
│   ├── ui_components/
│   │   └── README.md
│   ├── dormant/
│   │   └── README.md
│   └── deprecated/
│       └── README.md
│
├── self_development/
│   ├── issues.md
│   ├── ideas.md
│   ├── changelog.md
│   ├── experiments/
│   │   └── README.md
│   └── patches/
│       └── README.md
│
├── kernel/
│   ├── __init__.py
│   ├── supervisor.py
│   ├── version_manager.py
│   ├── health_check.py
│   └── rollback.py
│
├── releases/
│   ├── current/
│   │   └── README.md
│   ├── candidate/
│   │   └── README.md
│   └── previous/
│       └── README.md
│
├── logs/
│   ├── runtime.log
│   ├── development.log
│   └── health_check.log
│
└── tests/
    ├── test_health_check.py
    ├── test_intent_classifier.py
    ├── test_memory_router.py
    └── test_capability_registry.py
```

## 四、文档初始化要求

请初始化以下文档。可以先写简洁版本，但必须包含核心原则。

### docs/product_vision_and_v1_architecture.md

说明：

- 项目不是普通聊天机器人。
- 第一版目标是自举内核。
- 交互即开发。
- Agent 拥有 mind、memory、capabilities、self_development、kernel。
- 第一版不做手机端、语音识别、真实 MCP。
- 后续通过自我迭代长出功能。

### docs/constitution.md

说明：

- Agent 身份。
- 最高原则。
- 文件修改边界。
- 记忆与代码分离。
- 能力与偏好分离。
- candidate 修改机制。
- 不谎称完成。
- changelog 和 self_model 更新规则。

### docs/interaction_development_protocol.md

说明用户输入如何分类：

- 普通聊天。
- 偏好更新。
- 人格更新。
- listen policy 更新。
- 记忆更新。
- 新能力请求。
- 运行机制修改。
- bug 反馈。
- 文档更新。

并说明每类应该写到哪里。

### docs/memory_design.md

说明：

- memory/preferences
- memory/feedback
- memory/events
- memory/summaries
- memory/archive
- hit/sleep/wake 是后续目标。
- 第一版先做文本写入。

### docs/capability_design.md

说明：

- capability registry 结构。
- active/dormant/deprecated/candidate 状态。
- 新工具先注册为 candidate。
- 用户偏好不等于删除能力。

### docs/self_improvement_protocol.md

说明：

- 创建 issue。
- 创建 candidate。
- 修改 candidate。
- health check。
- promote。
- rollback。
- changelog。
- self_model 更新。

## 五、核心模块要求

### 1. file_store.py

提供基础文件读写能力。

需要支持：

- 读取 Markdown 文件。
- 追加 Markdown 段落。
- 覆盖 Markdown 文件。
- 确保目录存在。
- 写日志。
- 简单时间戳。

不要写复杂数据库，第一版用文件即可。

### 2. intent_classifier.py

实现基于规则的 intent 分类器。第一版不需要调用 LLM。

输入用户文本，输出：

```text
ordinary_chat
preference_update
persona_update
listen_policy_update
memory_update
new_capability_request
runtime_change_request
bug_report
documentation_update
self_development_request
```

可以用关键词和简单模式匹配。

示例规则：

- 包含“我喜欢”“我不喜欢”“我爱”“我不爱”“优先” → preference_update
- 包含“以后你说话”“你别”“你要更”“风格” → persona_update
- 包含“叫你”“唤醒”“你才应”“别插嘴”“skip” → listen_policy_update
- 包含“记住”“记录一下”“忘记” → memory_update
- 包含“加一个工具”“MCP”“新增能力”“点单”“查询工具” → new_capability_request
- 包含“hit 机制”“sleep 功能”“索引”“记忆整理”“运行机制” → runtime_change_request
- 包含“你刚才错了”“没反应”“误会”“不是叫你” → bug_report
- 包含“更新文档”“写到文档” → documentation_update
- 包含“继续完善你自己”“自我开发”“继续迭代” → self_development_request

需要保留可扩展接口，未来可替换为 LLM 分类。

### 3. memory_router.py

根据 intent 写入对应 memory 文件。

需要支持：

#### preference_update

如果涉及咖啡，写入：

```text
memory/preferences/coffee.md
```

否则写入：

```text
memory/preferences/general.md
```

写入内容包含：

- 时间
- 用户原话
- 推断偏好
- 适用场景
- 备注

#### memory_update

写入：

```text
memory/events/user_requested_memory.md
```

#### bug_report

写入：

```text
memory/feedback/interaction_errors.md
```

### 4. self_model_manager.py

负责更新：

```text
mind/self_model.md
```

每次重要修改后追加一段：

- 时间
- 发生了什么
- 修改了哪些文件
- 当前新增认知或限制
- 后续可能动作

### 5. capability_router.py

负责维护：

```text
capabilities/registry.md
```

当用户提出新能力请求时：

- 新增一个 candidate capability。
- 记录用户原话。
- 记录适用场景。
- 状态为 candidate。
- hit_count 初始为 0。
- 说明尚未实现。

不要假装工具已经可用。

### 6. agent_loop.py

负责 CLI 主循环。

流程：

```text
启动时检查目录和必要文件
读取基础 docs 和 mind 文件摘要
等待用户输入
分类 intent
根据 intent 调用对应 router
更新 self_model
写 changelog
回复用户
```

### 7. health_check.py

检查：

- 必要目录存在。
- 必要文件存在。
- registry 存在。
- mind 文件存在。
- docs 文件存在。
- self_development 文件存在。
- logs 可写。
- 测试模块可导入。

输出：

- pass / fail
- fail reason list

### 8. version_manager.py

第一版实现基础函数即可：

- create_candidate()
- promote_candidate()
- rollback_previous()

可以先使用目录复制伪实现或实际复制当前项目核心目录。

注意：不要在未测试情况下覆盖 current。

### 9. supervisor.py

第一版可以只提供简单入口：

- run_health_check()
- show_status()

不需要做真正守护进程。

## 六、CLI 回复要求

Agent 回复必须诚实。

如果只是写入记忆，要说“已记录”。

如果只是创建 issue，要说“已创建待开发任务”。

如果 capability 只是 candidate，要说“已注册为候选能力，尚未实现”。

如果当前版本暂不支持真实代码自修改，要说“当前自举内核已记录此机制修改请求，后续可由 candidate 修改流程实现”。

不要说“已完成”除非真的完成。

## 七、示例交互与预期效果

### 示例 1：偏好更新

用户：

```text
我不爱喝瑞幸，我爱喝星巴克。
```

预期：

- intent = preference_update
- 写入 `memory/preferences/coffee.md`
- 更新 `mind/self_model.md`
- 写入 `self_development/changelog.md`
- 回复：

```text
已记录到咖啡偏好中：你不爱喝瑞幸，更偏好星巴克。瑞幸相关能力如果以后存在，不会被删除，但会降低主动推荐优先级。
```

### 示例 2：listen policy

用户：

```text
以后我叫你大李的时候你才应，和别人聊天时别插嘴。
```

预期：

- intent = listen_policy_update
- 更新 `mind/listen_policy.md`
- 更新 self_model
- 写 changelog
- 回复：

```text
已更新交互规则：显式呼叫名增加“大李”；多人对话场景默认不主动回应，除非你明确叫我。
```

### 示例 3：人格更新

用户：

```text
你以后讨论产品想法时别太保守，先展开可能性。
```

预期：

- intent = persona_update
- 更新 `mind/persona.md`
- 回复确认。

### 示例 4：新能力请求

用户：

```text
你给自己加一个星巴克菜单查询工具。
```

预期：

- intent = new_capability_request
- 更新 `capabilities/registry.md`
- 创建 issue
- 状态 candidate
- 回复：

```text
已注册为候选能力：starbucks_menu_query。当前尚未实现真实查询工具，我已把它加入自我开发任务。
```

### 示例 5：运行机制请求

用户：

```text
你给记忆加一个 hit 机制，读得越多说明越重要。
```

预期：

- intent = runtime_change_request
- 创建 issue
- 不假装已经实现
- 回复：

```text
这是记忆运行机制修改请求。我已创建自我开发任务，涉及 memory_router 和 memory index。当前版本先记录需求，后续可通过 candidate 修改流程实现。
```

## 八、测试要求

请实现基础测试：

### test_health_check.py

测试必要目录和文件存在。

### test_intent_classifier.py

测试上述五类示例能被正确分类。

### test_memory_router.py

测试 preference_update 能写入 coffee.md 或 general.md。

### test_capability_registry.py

测试 new_capability_request 能在 registry 中创建 candidate 能力。

## 九、实现风格

请保持代码简单、可读、可扩展。

不要过早引入复杂框架。

不要引入真实 LLM API，第一版可以规则驱动。

不要实现真实语音系统。

不要实现真实 MCP。

不要实现真实手机 App。

重点是把“自我成长的文件结构和流程”跑通。

代码应尽量模块化，方便未来 Agent 自己修改。

## 十、完成后输出

完成后请输出：

1. 项目目录结构。
2. 如何运行 CLI。
3. 如何运行测试。
4. 已实现能力列表。
5. 未实现但已预留的后续能力。
6. 你认为下一步最应该让 Agent 自己开发的 3 个功能。

## 十一、最重要的验收标准

如果我运行 CLI，并输入：

```text
我不爱喝瑞幸，我爱喝星巴克。
```

项目应该真实修改 `memory/preferences/coffee.md`。

如果我输入：

```text
以后我叫你大李的时候你才应，和别人聊天时别插嘴。
```

项目应该真实修改 `mind/listen_policy.md`。

如果我输入：

```text
你给记忆加一个 hit 机制。
```

项目应该真实创建 `self_development/issues.md` 条目，而不是假装已经完成。

如果这三个闭环跑通，第一版自举内核就合格。
